# TERMEHEK BOT
### tahap 1
```git clone https://github.com/FighterTunnel/regis.git```

### tahap 2
```bash regis/main```


- CHANGE BOT
``` nano /root/regis/var.txt ```
 
- CHANGE TELE/WHTSAP
 ``` nano /root/id```